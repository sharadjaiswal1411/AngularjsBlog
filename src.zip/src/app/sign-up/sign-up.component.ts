import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService, AuthenticationService,UserService } from '../services/index';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
    model: any = {};
	validation_errors: any = {};
    loading = false;
	errors="";
    
  constructor( private router: Router,
        private userService: UserService,
        private alertService: AlertService) { }
  
  ngOnInit() {
    
    }
  register(){
	    this.loading = true;
        this.userService.create(this.model)
            .subscribe(
                data => {
                    this.alertService.success(data, true);
                    this.router.navigate(['/signin.html']);
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }

}
