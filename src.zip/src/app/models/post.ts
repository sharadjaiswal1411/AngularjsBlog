export class Post {
    id: number;
    title: string;
    content: string;
    excerpt: string;
	wall_id:number;
    meta_title: string;
	meta_description: string;
	slug: string;
	tags: any;
	status:string
}