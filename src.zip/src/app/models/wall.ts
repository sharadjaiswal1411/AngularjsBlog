export class Wall {
    id: number;
    title: string;
    content: string;
    excerpt: string;
    meta_title: string;
	meta_description: string;
	slug: string;
	status:string
}