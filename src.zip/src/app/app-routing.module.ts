import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SignInComponent } from './signin/signin.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { PublicComponent } from './layouts/public/public.component';
import { SecureComponent } from './layouts/secure/secure.component';
import { AuthGuard } from './guards/index';
import { AppComponent } from './app.component';

const PUBLIC_ROUTES: Routes = [
    { path: 'signin.html', component: SignInComponent},
    { path: 'signup.html', component: SignUpComponent},
    
];
const SECURE_ROUTES: Routes = [
   
    { path: 'posts', loadChildren: './post/post.module#PostModule', canActivate: [AuthGuard] },
    { path: 'walls', loadChildren: './wall/wall.module#WallModule', canActivate: [AuthGuard] },
    
];



const routes: Routes = [
    { path: '', redirectTo: '/', pathMatch: 'full', },
    { path: '', component: PublicComponent, data: { title: 'Public Views' }, children: PUBLIC_ROUTES },
    { path: '', component: SecureComponent, canActivate: [AuthGuard], data: { title: 'Secure Views' }, children: SECURE_ROUTES }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }