import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { AppRoutingModule  } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './comman/header/header.component';
import { SignInComponent } from './signin/signin.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AlertComponent } from './directives/index';
import { FormsModule }    from '@angular/forms';
import { AuthGuard } from './guards/index';
import { AlertService, AuthenticationService,UserService } from './services/index';
import { PaginationComponent } from './comman/pagination/pagination.component';
import { SidebarComponent } from './comman/sidebar/sidebar.component';
import { PublicComponent } from './layouts/public/public.component';
import { SecureComponent } from './layouts/secure/secure.component';
import { GallaryComponent } from './gallary/gallary.component';
import { UploadService } from './services/upload.service';
@NgModule({
  declarations: [
    AppComponent,
	HeaderComponent,
	SignInComponent,
	SignUpComponent,
	AlertComponent,
	PaginationComponent,
	SidebarComponent,
	PublicComponent,
	SecureComponent,
	GallaryComponent,
	
    ],
  imports: [
    BrowserModule,
	BrowserAnimationsModule,
	HttpModule,
	AppRoutingModule,
    FormsModule	
  ],
  providers: [ AuthGuard,
			   AlertService,
               AuthenticationService,
               UserService,
			   UploadService,
               		   
			 ],
  bootstrap: [AppComponent]
})
export class AppModule { }
