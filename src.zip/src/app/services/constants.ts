export class Constants {
  public static get API_END_POINT(): string { return "http://localhost:8000"; };
}