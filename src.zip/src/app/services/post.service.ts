import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Constants } from "../services/constants";
import { Post } from '../models/post';
import { Observable } from "rxjs/Rx"
@Injectable()
export class PostService {
    constructor(private http: Http) { }

    getAll() {
        return this.http.get(Constants.API_END_POINT+'/api/posts', this.jwt()).map((response: Response) => response.json());
    }
    getTags =(text: string): Observable<Response> => {
    const url = Constants.API_END_POINT+`/api/tags/search/${text}`;
		return this.http
			.get(url,this.jwt())
			.map(data => data.json());
    }
	
	getWalls =(text: string): Observable<Response> => {
		const url = Constants.API_END_POINT+`/api/walls/search/${text}`;
		return this.http
			.get(url,this.jwt())
			.map(data => data.json());
    }
    getById(id: number) {
        return this.http.get(Constants.API_END_POINT+'/api/posts/' + id, this.jwt()).map((response: Response) => response.json());
    }

    create(post: Post) {
        return this.http.post(Constants.API_END_POINT+'/api/posts', post, this.jwt()).map((response: Response) => response.json());
    }
	slugify(input:String){
		let slug = input.toLowerCase().trim();
         // replace invalid chars with spaces
        slug = slug.replace(/[^a-z0-9\s-]/g, '');
        // replace multiple spaces or hyphens with a single hyphen
        slug = slug.replace(/[\s-]+/g, '-');
 
        return slug;
	}
    update(post: Post) {
        return this.http.put(Constants.API_END_POINT+'/api/posts/' + post.id, post, this.jwt()).map((response: Response) => response.json());
    }

    delete(id: number) {
        return this.http.delete(Constants.API_END_POINT+'/api/posts/' + id, this.jwt()).map((response: Response) => response.json());
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.api_token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
            return new RequestOptions({ headers: headers });
        }
    }
}