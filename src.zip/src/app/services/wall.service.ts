import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Constants } from "../services/constants";
import { Wall } from '../models/wall';

@Injectable()
export class WallService {
    constructor(private http: Http) { }

    getAll() {
        return this.http.get(Constants.API_END_POINT+'/api/walls', this.jwt()).map((response: Response) => response.json());
    }

    getById(id: number) {
        return this.http.get(Constants.API_END_POINT+'/api/walls/' + id, this.jwt()).map((response: Response) => response.json());
    }

    create(wall: Wall) {
        return this.http.post(Constants.API_END_POINT+'/api/walls', wall, this.jwt()).map((response: Response) => response.json());
    }
	slugify(input:String){
		let slug = input.toLowerCase().trim();
         // replace invalid chars with spaces
        slug = slug.replace(/[^a-z0-9\s-]/g, '');
        // replace multiple spaces or hyphens with a single hyphen
        slug = slug.replace(/[\s-]+/g, '-');
 
        return slug;
	}
    update(wall: Wall) {
        return this.http.put(Constants.API_END_POINT+'/api/walls/' + wall.id, wall, this.jwt()).map((response: Response) => response.json());
    }

    delete(id: number) {
        return this.http.delete(Constants.API_END_POINT+'/api/walls/' + id, this.jwt()).map((response: Response) => response.json());
    }

    // private helper methods

    private jwt() {
        // create authorization header with jwt token
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser && currentUser.api_token) {
            let headers = new Headers({ 'Authorization': 'Bearer ' +currentUser.api_token });
            return new RequestOptions({ headers: headers });
        }
    }
}