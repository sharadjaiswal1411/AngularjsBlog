import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService,WallService,AuthenticationService } from '../../services/index';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  model: any = {};
  slug:any={};
  validation_errors: any = {};
  loading = false;
  constructor( private router: Router,
        private wallService: WallService,
        private alertService: AlertService,
		private route:ActivatedRoute,
		private authenticationService:AuthenticationService
		) { }

  ngOnInit() {
	this.route.params.subscribe((params: any) => {
      this.slug = params.id;
    });
	this.wallService.getById(this.slug)
            .subscribe(
                data => {
					this.model=data;
                },
                error => {
					
					if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                   
                });

	  
  }
  
  update(){
	    this.loading = true;
        this.wallService.update(this.model)
            .subscribe(
                data => {
                    this.alertService.success(data, true);
                    this.router.navigate(['/walls']);
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }
}
