import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService,WallService,AuthenticationService } from '../../services/index';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  model: any = {};
  validation_errors: any = {};
  loading = false;
  constructor( private router: Router,
        private wallService: WallService,
        private alertService: AlertService,
		private authenticationService:AuthenticationService
		) { }

  ngOnInit() {
	  this.model.status="draft";
  }
  generateSlug(){
	  
	this.model.slug=  this.wallService.slugify(this.model.title); 
  
  }
  create(){
	    this.loading = true;
        this.wallService.create(this.model)
            .subscribe(
                data => {
                    this.alertService.success(data, true);
                    this.router.navigate(['/walls']);
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  alert(error._body);
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }
}
