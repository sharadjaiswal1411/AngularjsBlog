import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertService,WallService,AuthenticationService } from '../../services/index';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  walls: any = [];
  validation_errors: any = {};
  loading = true;
  
  constructor( private router: Router,
        private wallService: WallService,
        private alertService: AlertService,
		private authenticationService:AuthenticationService
		) { }

  ngOnInit() {
	 
	        this.wallService.getAll()
            .subscribe(
                data => {
                    this.alertService.success(data, true);
					this.walls=data.data;
                    
                },
                error => {
					//alert();
					if(error.status==422){
					  this.validation_errors=JSON.parse(error._body);
					 // console.log(this.validation_errors);
					 
					}else if(error.status==401){
					  this.authenticationService.logout();
					  this.router.navigate(['/signin.html']);
					 // console.log(this.validation_errors);
					 
					}else{
					  this.alertService.error(error);
					}
					//this.alertService.error(JSON.parse(error._body).email);
                    this.loading = false;
                });
  }

}
