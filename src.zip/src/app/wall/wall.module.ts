import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }    from '@angular/forms';
import { WallRoutingModule } from './wall-routing.module';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { ViewComponent } from './view/view.component';
import { ListComponent } from './list/list.component';
import { AlertService,WallService } from '../services/index';

@NgModule({
  imports: [
    CommonModule,
	WallRoutingModule,
	FormsModule
  ],
  providers: [ 
			   AlertService,
               WallService,
               		   
			 ],
  declarations: [
		  AddComponent,
		  EditComponent,
		  ViewComponent,
		  ListComponent,
		  ]
		  
})
export class WallModule { }
